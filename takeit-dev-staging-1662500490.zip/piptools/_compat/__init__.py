from .click import IS_CLICK_VER_8_PLUS
from .pip_compat import PIP_VERSION, parse_requirements

__all__ = ["PIP_VERSION", "IS_CLICK_VER_8_PLUS", "parse_requirements"]
